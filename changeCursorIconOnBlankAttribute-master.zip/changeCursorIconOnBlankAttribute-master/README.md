# changeCursorIconOnBlankAttribute
Changes the cursor when you hover over a link that has a `_blank` attribute (to tell you it will open in a new window)
